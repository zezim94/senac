<?php
include '../verificaLogin.php';
?>

<html>

<head>
  <meta charset="utf-8" />
  <title>App Help Desk</title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

  <style>
    .card-abrir-chamado {
      padding: 30px 0 0 0;
      width: 100%;
      margin: 0 auto;
    }
  </style>
</head>

<body>

  <?php include '../LAYOUT/nav.php'; ?>

  <div class="container">
    <div class="row">

      <div class="card-abrir-chamado">
        <div class="card">

          <?php
          if (isset($_GET['message']) && $_GET['message'] === 'sucess'):
            ?>
            <div class="alert alert-success" role="alert">
              Chamado cadastrado com sucesso !
            </div>
            <?php
            unset($_GET['message']);
          elseif (isset($_GET['message']) && $_GET['message'] === 'error'):
            ?>
            <div class="alert alert-danger" role="alert">
              Erro ao cadastrar chamado !
            </div>

            <?php
          endif;
          unset($_GET['message']);
          ?>

          <div class="card-header">
            Abertura de chamado
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col">

                <form action="processaAbrirChamado.php" method="post">
                  <div class="form-group">
                    <label>Título</label>
                    <input name="titulo" type="text" class="form-control" placeholder="Título">
                  </div>

                  <div class="form-group">
                    <label>Categoria</label>
                    <select name="categoria" class="form-control">
                      <option value="criação_usuario">Criação Usuário</option>
                      <option value="impressora">Impressora</option>
                      <option value="hardware">Hardware</option>
                      <option value="software">Software</option>
                      <option value="rede">Rede</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Descrição</label>
                    <textarea name="descricao" class="form-control" rows="3"></textarea>
                  </div>

                  <div class="row mt-5">
                    <div class="col-6">
                      <a href="../USUARIO/home.php" class="btn btn-lg btn-warning btn-block">Voltar</a>
                    </div>

                    <div class="col-6">
                      <button class="btn btn-lg btn-info btn-block" type="submit">Abrir</button>
                    </div>
                  </div>
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</body>

</html>